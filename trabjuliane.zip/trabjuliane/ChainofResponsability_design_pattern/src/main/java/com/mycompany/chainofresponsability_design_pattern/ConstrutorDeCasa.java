
package com.mycompany.chainofresponsability_design_pattern;

public abstract class ConstrutorDeCasa {
    
    public final void construirCasa() {
        construirEstrutura();
        adicionarCobertura();
        adicionarParedes();
        adicionarPortasEJanelas();
        decorarCasa();
    }

    protected abstract void construirEstrutura();
    protected abstract void adicionarCobertura();
    protected abstract void adicionarParedes();
    protected abstract void adicionarPortasEJanelas();
    
    protected void decorarCasa() {
        System.out.println("Decoração básica concluída.");
    }
}

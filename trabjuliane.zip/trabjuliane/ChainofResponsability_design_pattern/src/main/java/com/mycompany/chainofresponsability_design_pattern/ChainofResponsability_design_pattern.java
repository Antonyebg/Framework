
package com.mycompany.chainofresponsability_design_pattern;

public class ChainofResponsability_design_pattern {

    public static void main(String[] args) {
        ConstrutorDeCasa construtorMadeira = new ConstrutorCasaMadeira();
        construtorMadeira.construirCasa();

        System.out.println("--------------------------");

        ConstrutorDeCasa construtorConcreto = new ConstrutorCasaConcreto();
        construtorConcreto.construirCasa();
    }
}

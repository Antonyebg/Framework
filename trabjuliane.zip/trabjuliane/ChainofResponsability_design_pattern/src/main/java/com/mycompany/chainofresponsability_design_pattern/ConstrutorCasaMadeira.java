package com.mycompany.chainofresponsability_design_pattern;

public class ConstrutorCasaMadeira extends ConstrutorDeCasa {

    @Override
    protected void construirEstrutura() {
        System.out.println("Construindo estrutura de madeira.");
    }

    @Override
    protected void adicionarCobertura() {
        System.out.println("Adicionando telhado de madeira.");
    }

    @Override
    protected void adicionarParedes() {
        System.out.println("Adicionando paredes de madeira.");
    }

    @Override
    protected void adicionarPortasEJanelas() {
        System.out.println("Adicionando portas e janelas de madeira.");
    }
}


package com.mycompany.chainofresponsability_design_pattern;

public class ConstrutorCasaConcreto extends ConstrutorDeCasa {

    @Override
    protected void construirEstrutura() {
        System.out.println("Construindo estrutura de concreto.");
    }

    @Override
    protected void adicionarCobertura() {
        System.out.println("Adicionando telhado de concreto.");
    }

    @Override
    protected void adicionarParedes() {
        System.out.println("Adicionando paredes de concreto.");
    }

    @Override
    protected void adicionarPortasEJanelas() {
        System.out.println("Adicionando portas e janelas de vidro.");
    }

    @Override
    protected void decorarCasa() {
        System.out.println("Decoração premium concluída.");
    }

}

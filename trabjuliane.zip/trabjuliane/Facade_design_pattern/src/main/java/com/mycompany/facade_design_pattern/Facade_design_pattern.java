
package com.mycompany.facade_design_pattern;

public class Facade_design_pattern {

    public static void main(String[] args) {
        SistemaCinemaFacade sistemaCinema = new SistemaCinemaFacade();

        // Compra de ingressos
        sistemaCinema.comprarIngresso(4);
    }
}

package com.mycompany.facade_design_pattern;

public class Assento {
    public boolean assentoDisponivel(int quantidade) {
        // Verificar a disponibilidade de assentos
        System.out.println(quantidade + " assentos estão disponíveis.");
        return true;
    }
}

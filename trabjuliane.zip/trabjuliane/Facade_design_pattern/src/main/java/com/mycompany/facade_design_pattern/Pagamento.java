package com.mycompany.facade_design_pattern;


public class Pagamento {
    public void realizarPagamento(double valor) {
        // Efetuar o pagamento
        System.out.println("Pagamento de R$" + valor + " realizado com sucesso.");
    }
}

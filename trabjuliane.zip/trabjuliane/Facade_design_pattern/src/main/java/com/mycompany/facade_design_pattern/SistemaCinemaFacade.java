package com.mycompany.facade_design_pattern;


public class SistemaCinemaFacade {
    private Assento verificadorAssentos;
    private Ingresso compradorIngresso;
    private Pagamento sistemaPagamento;

    public SistemaCinemaFacade() {
        this.verificadorAssentos = new Assento();
        this.compradorIngresso = new Ingresso();
        this.sistemaPagamento = new Pagamento();
    }

    public void comprarIngresso(int quantidade) {
        if (verificadorAssentos.assentoDisponivel(quantidade)) {
            compradorIngresso.comprarIngresso(quantidade);
            sistemaPagamento.realizarPagamento(quantidade * 10.0); // Preço fictício de R$10 por ingresso
        } else {
            System.out.println("Desculpe, não há assentos disponíveis.");
        }
    }
}

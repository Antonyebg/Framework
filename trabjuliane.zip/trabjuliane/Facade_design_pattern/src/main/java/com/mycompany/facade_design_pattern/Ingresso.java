package com.mycompany.facade_design_pattern;

public class Ingresso {
    public void comprarIngresso(int quantidade) {
        // Lógica para comprar ingressos
        System.out.println(quantidade + " ingressos comprados com sucesso.");
    }
}

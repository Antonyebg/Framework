package template_method_design_pattern;


public class Template_Method_design_pattern {

  
    public static void main(String[] args) {
        Bebida cafe = new Cafe();
        Bebida cha = new Cha();

        System.out.println("Preparando café:");
        cafe.prepararBebida();

        System.out.println("\nPreparando chá:");
        cha.prepararBebida();
    }
    
}

package template_method_design_pattern;


public class Cha extends Bebida{
     @Override
    void misturarIngredientes() {
        System.out.println("Misturando chá");
    }

    @Override
    void adicionarExtras() {
        System.out.println("Adicionando limão");
    }
}

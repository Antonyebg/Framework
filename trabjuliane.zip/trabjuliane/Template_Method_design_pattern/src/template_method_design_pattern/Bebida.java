package template_method_design_pattern;


public abstract class Bebida {
    
 // Método Template Method que define a estrutura do algoritmo
    public final void prepararBebida() {
        ferverAgua();
        misturarIngredientes();
        despejarNaXicara();
        adicionarExtras();
    }

    // Métodos abstratos que as subclasses devem implementar
    abstract void misturarIngredientes();
    abstract void adicionarExtras();

    // Métodos concretos com implementação padrão
    public void ferverAgua() {
        System.out.println("Fervendo água");
    }

    public void despejarNaXicara() {
        System.out.println("Despejando na xícara");
    }
}

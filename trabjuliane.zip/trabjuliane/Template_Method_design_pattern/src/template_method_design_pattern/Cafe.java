package template_method_design_pattern;

public class Cafe extends Bebida{
    @Override
    void misturarIngredientes() {
        System.out.println("Misturando café solúvel");
    }

    @Override
    void adicionarExtras() {
        System.out.println("Adicionando açúcar e leite");
    }
}


package proxy_design_pattern;

public class Proxy implements Subject{
    private RealSubject realSubject;

    @Override
    public void request() {
        // Aqui, o Proxy controla o acesso ao objeto real
        if (realSubject == null) {
            realSubject = new RealSubject();
        }
        realSubject.request();
    }
}


package proxy_design_pattern;


public class Proxy_design_pattern {

 
    public static void main(String[] args) {
        Proxy proxy = new Proxy();

        // Chamada ao método request através do Proxy
        proxy.request();
    }
    
}


package proxy_design_pattern;

public interface Subject {
    void request();
}
